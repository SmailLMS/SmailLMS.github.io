﻿$(document).ready(function() {
						   
	var slides = $(".slider .slides").children(".slide");
	var width = $(".slider .slides").width(); 
	var i = slides.length;
	var offset = i * width;
	i--;
	$(".slider .slides").css('width',offset);
	
	offset = 0;
	$("body .slider .next").click(function(){
		if (offset < width * i) {	
			offset += width; 
			$(".slider .slides").css("transform","translate3d(-"+offset+"px, 0px, 0px)");
		}
	});


	$("body .slider .prev").click(function(){	
		if (offset > 0) { 
			offset -= width; 
			$(".slider .slides").css("transform","translate3d(-"+offset+"px, 0px, 0px)");
		}
	});

});
$(document).ready(function() {
						   
	var slides = $(".sliderl .slidesl").children(".slidel");
	var width = $(".sliderl .slidesl").width(); 
	var i = slides.length; 
	var offset = i * width; 
	i--; 
	$(".sliderl .slidesl").css('width',offset); 
	
	offset = 0;
	$("body .sliderl .nextl").click(function(){
		if (offset < width * i) {
			offset += width; 
			$(".sliderl .slidesl").css("transform","translate3d(-"+offset+"px, 0px, 0px)"); 
		}
	});


	$("body .sliderl .prevl").click(function(){	
		if (offset > 0) {
			offset -= width; 
			$(".sliderl .slidesl").css("transform","translate3d(-"+offset+"px, 0px, 0px)");
		}
	});

});
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("shows");
}
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('shows')) {
        openDropdown.classList.remove('shows');
      }
    }
  }
}